/*Peyton Anderson
Csis 1400
Group Project 2
Version 1
*/
package groupproject2;

import java.util.Scanner;
import javax.swing.JOptionPane;


 
public class GroupProject2 {
    public static void main( String[] args )
   {
       Scanner input = new Scanner(System.in);
       String answer;
       
     do{
      JOptionPane.showMessageDialog(null,"Lets see what you got!", 
           "Poker", JOptionPane.PLAIN_MESSAGE );
      Deck myDeckOfCards = new Deck();
      myDeckOfCards.shuffle();
      
      Card[] hand = new Card[5];
    
      for ( int i = 0; i < 5; i++ )
      {
         hand[i] = myDeckOfCards.dealCard();
         System.out.println(hand[i]);
      }
     

    
      int pairs = myDeckOfCards.pairs(hand);
      myDeckOfCards.twoPairs(pairs);
      int threeOfAKind = myDeckOfCards.threeOfAKind(hand);
     
      System.out.println("Do you want to play again? Yes or No");
      answer = input.next();
     
     }  while (answer.equals("Yes"));
   }
    
}

    
    

