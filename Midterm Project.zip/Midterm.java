//CSIS 1400
//MIDTERM
//PEYTON ANDERSON
//VERSION 1

import java.util.Scanner; 
import javax.swing.JOptionPane; 
 
public class Midterm {
   public static void main(String[] args) {
   
   
      money tradeIN = new money ();
      tradeIN.tradein();

     money phoneM = new money ();
     phoneM.phoneColors();

JOptionPane.showMessageDialog(null,"Your phone number will be (678)-999-8212", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );

   }
  }
   
    
    

 