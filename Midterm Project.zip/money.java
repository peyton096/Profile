import java.util.Scanner;
import javax.swing.JOptionPane; 

public class money {

   public void tradein(){
      JOptionPane.showMessageDialog(null,"Welcome to AT&T", 
         "Welcome to AT&T", JOptionPane.PLAIN_MESSAGE );
      String userInput = 
         JOptionPane.showInputDialog("Would you like to trade in your old phone and apply the price towards the new one? Yes (1)  or No (2)" );
      int userChoice = Integer.parseInt(userInput);  
      if(userChoice == 1){
         JOptionPane.showMessageDialog(null,"Okay, we will take off $250 the new phone cost.", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
      }
      else{
         JOptionPane.showMessageDialog(null,"Sorry about that.", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
      } 
      String userInput1 = 
         JOptionPane.showInputDialog("Would you like to pay for it all up front or set up a payment plan? Full (1) or Payment plan (2)");
      int payplan = Integer.parseInt(userInput1);
      if(payplan == 1){
         JOptionPane.showMessageDialog(null,"okay, lets look at the options of the phones and their full prices", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
      }
      if(payplan == 2){
         JOptionPane.showMessageDialog(null,"okay, you can pay $30 a month until it's paid off", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
      }
   }
   public void phoneColors(){
      JOptionPane.showMessageDialog(null,"All of the phones come with a free case but they have different storage options", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
      JOptionPane.showMessageDialog(null,"Lets look at the different color options for the Samsung phones.", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
      String userInput = 
         JOptionPane.showInputDialog("You can choose red, black or white. which color would you like? Red (1), black (2), white (3)?");
      int color = Integer.parseInt(userInput);
      if(color == 1){
         JOptionPane.showMessageDialog(null,"Lets look at the options red comes with", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
         String userInput1 =
            JOptionPane.showInputDialog("The red one has 64 GB or 256 GB. Which option would you like?");
         int size = Integer.parseInt(userInput1);
         if(size == 64){
            JOptionPane.showMessageDialog(null,"that one is $600 *or $350 after trade in", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );
         }
         else{
            JOptionPane.showMessageDialog(null,"that one is $800 *or $550 after trade in", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );
         }
      }
      if(color == 2){
         JOptionPane.showMessageDialog(null,"Lets look at the options black comes with", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
         String userInput1 =
            JOptionPane.showInputDialog("The black one has 256 GB or 1TB. Which option would you like?");
         int size = Integer.parseInt(userInput1);
         if(size == 256){
            JOptionPane.showMessageDialog(null,"that one is $600 *or $350 after trade in", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );
         }
         else{
            JOptionPane.showMessageDialog(null,"that one is $800 *or $550 after trade in", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );
         }
      }
      if(color == 3){
         JOptionPane.showMessageDialog(null,"Lets look at the options white comes with", 
            "AT&T", JOptionPane.PLAIN_MESSAGE );
         String userInput2 =
            JOptionPane.showInputDialog("The white one has 64 GB, 256 GB and 1TB. Which option would you like?");
         int size = Integer.parseInt(userInput2);
         if(size == 64){
            System.out.println("that one is $600 *or $350 after trade in");
         }
         if(size == 256){
            JOptionPane.showMessageDialog(null,"that one is $800 *or $550 after trade in", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );
         }
         if(size == 1){
            JOptionPane.showMessageDialog(null,"that one is $1000 *or $750 after trade in", 
               "AT&T", JOptionPane.PLAIN_MESSAGE );
         }
      
      
      
      }
   }
}

