
package groupproject2;

import java.util.Random;
import javax.swing.JOptionPane;



public class Deck {
    private static final String[] rank = 
      { "Ace", "Deuce", "Three", "Four", "Five", "Six", 
        "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King" };
   private static final String[] suit = 
      { "Hearts", "Diamonds", "Clubs", "Spades" };
   
   private static final Random randomNumbers = new Random(); 
   private static final int NumOfCards = 52;
   
   private Card[] deck;
   private int currentCard;
 
public Deck(){
   deck = new Card[NumOfCards];
   
   for( int i = 0; i < deck.length; i++){
       deck[i] = 
               new Card(rank [i%13],suit[i/13]);
   }
}
public void shuffle(){
    currentCard = 0;
          for ( int first = 0; first < deck.length; first++ ) 
      {
         int second =  randomNumbers.nextInt( NumOfCards );
         Card temp = deck[first];        
         deck[first] = deck[second];
         deck[second] = temp;
    }
}
public Card dealCard()
   {
      if ( currentCard < deck.length )
         return deck[currentCard++];
      else        
         return null;
   }
private int[] totalHand(Card hand[])
   {
      int[] numbers = new int[rank.length];
      for ( int i = 0; i < 13; i++ )
         numbers[i] = 0;
      
      for ( int h = 0; h < hand.length; h++ )
      {
         for ( int f = 0; f < 13; f++ )
         {
            if ( hand[h].getRank() == rank[f] )
               ++numbers[f];
         }
      }
      return numbers;  
   }
public int pairs(Card hand[])
   {
      int Pairs = 0;
      int[] numbers = totalHand(hand);

      
      for ( int k = 0; k < numbers.length; k++ )
      {
         if ( numbers[k] == 2 ) 
         {
          JOptionPane.showMessageDialog(null,"A Pair of " + rank[k] +"s!", 
           "Poker", JOptionPane.PLAIN_MESSAGE );
             //System.out.printf( "Pair of %ss\n", rank[k] );
            ++Pairs;
         }
	   }

      return Pairs;
   }
public int threeOfAKind( Card hand[] )
   {
      int ThreeOfaKind = 0;
      int[] numbers = totalHand(hand);
      
      for ( int k = 0; k < numbers.length; k++ )
      {
         if ( numbers [k] == 3 ) 
         {
        JOptionPane.showMessageDialog(null,"Three of a kind!" + rank[k], 
           "Poker", JOptionPane.PLAIN_MESSAGE );
            ++ThreeOfaKind;
            break;
         }
      }

      return ThreeOfaKind;
   }
public void twoPairs(int pairs){
     if (pairs == 2)
         JOptionPane.showMessageDialog(null,"You have 2 pairs!", 
           "Poker", JOptionPane.PLAIN_MESSAGE );
         //System.out.println("You have 2 pairs!");
 }
}
       

