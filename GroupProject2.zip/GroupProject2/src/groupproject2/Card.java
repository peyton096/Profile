
package groupproject2;


public class Card {

    private String rank;
    private String suit;        

   public Card( String cardRank, String cardSuit )
   {
      rank = cardRank;
      suit = cardSuit;
   }
   public String getRank()
   {
      return rank;
   }       
   public String getSuit()
   {
      return suit;
   } 
   public String toString() 
   { 
      return rank + " of " + suit;
   } 
}

